package business;

import java.util.List;

import javax.ejb.Local;

import src.Models.Order;

@Local
public interface OrdersBusinessInterface {
	public List<Order> getOrders();
}
