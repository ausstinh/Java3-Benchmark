package business;

import java.sql.Connection;

import javax.ejb.EJB;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.ejb.MessageDriven;
import javax.ejb.ActivationConfigProperty;

import database.OrderDataService;
import src.Models.Order;

@MessageDriven(
        activationConfig = { @ActivationConfigProperty(
                propertyName = "destination", propertyValue = "Order"), @ActivationConfigProperty(
                propertyName = "destinationType", propertyValue = "javax.jms.Queue")
        },
        mappedName = "java:/jms/queue/Order")
public class OrderMessageService implements MessageListener {

	@EJB
	OrderDataService service;
	@Override
	public void onMessage(Message message) {
		// Send a Message for an Order
				try 
				{
					if(message instanceof TextMessage) {
						System.out.print("===========> OrderMessageService.onMessage() with a Text Message: " + ((TextMessage)message).getText());
					}
					else if(message instanceof ObjectMessage) {
						System.out.println("============ OrderMessageService.onMessage() with a Send Order MEssage.");
						service.create((Order)((ObjectMessage)message).getObject());
					}
					else {
						System.out.println("=============> OrderMessageService.onMssage() with UNKNOWN Message type");
					}
				} 
				catch (JMSException e) 
				{
					e.printStackTrace();
				}	
		
	}

}
